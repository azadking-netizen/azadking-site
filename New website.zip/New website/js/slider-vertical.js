let vSlides = document.querySelectorAll(".v-slide");
let vIndex = 0;
let startY = 0;

function showVSlide(index) {
  vSlides.forEach((s, i) => {
    s.classList.remove("active", "prev");
    if (i === index) s.classList.add("active");
    if (i === index - 1) s.classList.add("prev");
  });
}

function nextVSlide() {
  if (vIndex < vSlides.length - 1) {
    vIndex++;
    showVSlide(vIndex);
  }
}

function prevVSlide() {
  if (vIndex > 0) {
    vIndex--;
    showVSlide(vIndex);
  }
}

// Touch swipe
document.addEventListener("touchstart", e => {
  startY = e.touches[0].clientY;
});

document.addEventListener("touchend", e => {
  let endY = e.changedTouches[0].clientY;

  if (startY - endY > 50) nextVSlide();
  if (endY - startY > 50) prevVSlide();
});

// Safe init
window.onload = () => {
  vSlides = document.querySelectorAll(".v-slide");
  showVSlide(vIndex);
};