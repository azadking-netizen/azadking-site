const users = [
  { user: "User", pass: "user008" },
  { user: "Azadking", pass: "azadking" },
  { user: "Hunter03", pass: "habibi" },
  { user: "Saqib07", pass: "benstokes" },
  { user: "Aimbot032", pass: "aimbot01" },
  { user: "Vader008", pass: "vader03" },
  { user: "Jalal003", pass: "jalal03" },
  { user: "Saksham08", pass: "shivaji06" },
  { user: "Godman019", pass: "godman002" }
];

// Check if already logged in
window.onload = () => {
  if (sessionStorage.getItem("loggedIn") === "true") {
    window.location.href = "./main.html";
  }
};

function login() {
  const u = document.getElementById("username").value.trim();
  const p = document.getElementById("password").value.trim();
  const err = document.getElementById("error");

  const valid = users.find(x => x.user === u && x.pass === p);

  if (valid) {
    sessionStorage.setItem("loggedIn", "true");
    err.innerText = ""; // clear old error
    window.location.href = "./main.html";
  } else {
    err.innerText = "Invalid username or password";
  }
}