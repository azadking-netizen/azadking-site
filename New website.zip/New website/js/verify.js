function startVerify(targetUrl) {
  const overlay = document.getElementById("verify-overlay");
  const timerText = document.getElementById("timer");
  const continueBtn = document.getElementById("continueBtn");

  if (!overlay || !timerText || !continueBtn) return;

  overlay.style.display = "flex";
  continueBtn.style.display = "none";

  let time = 4;
  timerText.innerText = time;

  const interval = setInterval(() => {
    time--;
    timerText.innerText = time;

    if (time <= 0) {
      clearInterval(interval);
      continueBtn.style.display = "block";

      continueBtn.onclick = () => {
        overlay.style.display = "none";

        if (targetUrl && targetUrl !== "#") {
          window.open(targetUrl, "_blank");
        }
      };
    }
  }, 1000);
}